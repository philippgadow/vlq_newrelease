#### VLB Hb(yy) nominal samples, including t-channel processes (with reweighting, LO PDF)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 108000 | ZBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 108001 | ZBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 108002 | ZBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 108003 | ZBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 108004 | ZBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 108005 | ZBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 108006 | ZBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 108007 | ZBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 108008 | ZBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 108009 | ZBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 108010 | ZBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 108011 | ZBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 108012 | ZBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 108013 | ZBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 108014 | ZBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 108015 | ZBH(yy)b (sig) | 2400 | 1.0      | yes      |
| 108016 | WBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 108017 | WBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 108018 | WBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 108019 | WBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 108020 | WBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 108021 | WBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 108022 | WBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 108023 | WBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 108024 | WBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 108025 | WBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 108026 | WBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 108027 | WBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 108028 | WBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 108029 | WBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 108030 | WBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 108031 | WBH(yy)b (sig) | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |
