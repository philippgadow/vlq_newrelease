#### VLB Hb nominal samples, including t-channel processes (with reweighting, LO PDF)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 107000 | ZBHb (sig)     | 1000 | 0.4      | yes      |
| 107001 | ZBHb (sig)     | 1000 | 1.0      | yes      |
| 107002 | ZBHb (sig)     | 1200 | 0.4      | yes      |
| 107003 | ZBHb (sig)     | 1200 | 1.0      | yes      |
| 107004 | ZBHb (sig)     | 1400 | 0.4      | yes      |
| 107005 | ZBHb (sig)     | 1400 | 1.0      | yes      |
| 107006 | ZBHb (sig)     | 1600 | 0.4      | yes      |
| 107007 | ZBHb (sig)     | 1600 | 1.0      | yes      |
| 107008 | ZBHb (sig)     | 1800 | 0.4      | yes      |
| 107009 | ZBHb (sig)     | 1800 | 1.0      | yes      |
| 107010 | ZBHb (sig)     | 2000 | 0.4      | yes      |
| 107011 | ZBHb (sig)     | 2000 | 1.0      | yes      |
| 107012 | ZBHb (sig)     | 2200 | 0.4      | yes      |
| 107013 | ZBHb (sig)     | 2200 | 1.0      | yes      |
| 107014 | ZBHb (sig)     | 2400 | 0.4      | yes      |
| 107015 | ZBHb (sig)     | 2400 | 1.0      | yes      |
| 107016 | WBHb (sig)     | 1000 | 0.4      | yes      |
| 107017 | WBHb (sig)     | 1000 | 1.0      | yes      |
| 107018 | WBHb (sig)     | 1200 | 0.4      | yes      |
| 107019 | WBHb (sig)     | 1200 | 1.0      | yes      |
| 107020 | WBHb (sig)     | 1400 | 0.4      | yes      |
| 107021 | WBHb (sig)     | 1400 | 1.0      | yes      |
| 107022 | WBHb (sig)     | 1600 | 0.4      | yes      |
| 107023 | WBHb (sig)     | 1600 | 1.0      | yes      |
| 107024 | WBHb (sig)     | 1800 | 0.4      | yes      |
| 107025 | WBHb (sig)     | 1800 | 1.0      | yes      |
| 107026 | WBHb (sig)     | 2000 | 0.4      | yes      |
| 107027 | WBHb (sig)     | 2000 | 1.0      | yes      |
| 107028 | WBHb (sig)     | 2200 | 0.4      | yes      |
| 107029 | WBHb (sig)     | 2200 | 1.0      | yes      |
| 107030 | WBHb (sig)     | 2400 | 0.4      | yes      |
| 107031 | WBHb (sig)     | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |
