#### VLB Hb nominal samples, including t-channel processes (with reweighting)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 103000 | ZBHb (sig)     | 1000 | 0.4      | yes      |
| 103001 | ZBHb (sig)     | 1000 | 1.0      | yes      |
| 103002 | ZBHb (sig)     | 1200 | 0.4      | yes      |
| 103003 | ZBHb (sig)     | 1200 | 1.0      | yes      |
| 103004 | ZBHb (sig)     | 1400 | 0.4      | yes      |
| 103005 | ZBHb (sig)     | 1400 | 1.0      | yes      |
| 103006 | ZBHb (sig)     | 1600 | 0.4      | yes      |
| 103007 | ZBHb (sig)     | 1600 | 1.0      | yes      |
| 103008 | ZBHb (sig)     | 1800 | 0.4      | yes      |
| 103009 | ZBHb (sig)     | 1800 | 1.0      | yes      |
| 103010 | ZBHb (sig)     | 2000 | 0.4      | yes      |
| 103011 | ZBHb (sig)     | 2000 | 1.0      | yes      |
| 103012 | ZBHb (sig)     | 2200 | 0.4      | yes      |
| 103013 | ZBHb (sig)     | 2200 | 1.0      | yes      |
| 103014 | ZBHb (sig)     | 2400 | 0.4      | yes      |
| 103015 | ZBHb (sig)     | 2400 | 1.0      | yes      |
| 103016 | WBHb (sig)     | 1000 | 0.4      | yes      |
| 103017 | WBHb (sig)     | 1000 | 1.0      | yes      |
| 103018 | WBHb (sig)     | 1200 | 0.4      | yes      |
| 103019 | WBHb (sig)     | 1200 | 1.0      | yes      |
| 103020 | WBHb (sig)     | 1400 | 0.4      | yes      |
| 103021 | WBHb (sig)     | 1400 | 1.0      | yes      |
| 103022 | WBHb (sig)     | 1600 | 0.4      | yes      |
| 103023 | WBHb (sig)     | 1600 | 1.0      | yes      |
| 103024 | WBHb (sig)     | 1800 | 0.4      | yes      |
| 103025 | WBHb (sig)     | 1800 | 1.0      | yes      |
| 103026 | WBHb (sig)     | 2000 | 0.4      | yes      |
| 103027 | WBHb (sig)     | 2000 | 1.0      | yes      |
| 103028 | WBHb (sig)     | 2200 | 0.4      | yes      |
| 103029 | WBHb (sig)     | 2200 | 1.0      | yes      |
| 103030 | WBHb (sig)     | 2400 | 0.4      | yes      |
| 103031 | WBHb (sig)     | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |
