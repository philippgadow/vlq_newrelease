#### VLB Hb(yy) nominal samples, including t-channel processes (with reweighting, LO PDF)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 106000 | ZBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 106001 | ZBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 106002 | ZBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 106003 | ZBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 106004 | ZBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 106005 | ZBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 106006 | ZBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 106007 | ZBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 106008 | ZBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 106009 | ZBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 106010 | ZBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 106011 | ZBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 106012 | ZBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 106013 | ZBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 106014 | ZBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 106015 | ZBH(yy)b (sig) | 2400 | 1.0      | yes      |
| 106016 | WBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 106017 | WBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 106018 | WBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 106019 | WBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 106020 | WBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 106021 | WBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 106022 | WBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 106023 | WBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 106024 | WBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 106025 | WBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 106026 | WBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 106027 | WBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 106028 | WBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 106029 | WBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 106030 | WBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 106031 | WBH(yy)b (sig) | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |
