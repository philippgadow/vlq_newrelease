#### VLB Hb nominal samples, including t-channel processes (with reweighting, LO PDF)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 105000 | ZBHb (sig)     | 1000 | 0.4      | yes      |
| 105001 | ZBHb (sig)     | 1000 | 1.0      | yes      |
| 105002 | ZBHb (sig)     | 1200 | 0.4      | yes      |
| 105003 | ZBHb (sig)     | 1200 | 1.0      | yes      |
| 105004 | ZBHb (sig)     | 1400 | 0.4      | yes      |
| 105005 | ZBHb (sig)     | 1400 | 1.0      | yes      |
| 105006 | ZBHb (sig)     | 1600 | 0.4      | yes      |
| 105007 | ZBHb (sig)     | 1600 | 1.0      | yes      |
| 105008 | ZBHb (sig)     | 1800 | 0.4      | yes      |
| 105009 | ZBHb (sig)     | 1800 | 1.0      | yes      |
| 105010 | ZBHb (sig)     | 2000 | 0.4      | yes      |
| 105011 | ZBHb (sig)     | 2000 | 1.0      | yes      |
| 105012 | ZBHb (sig)     | 2200 | 0.4      | yes      |
| 105013 | ZBHb (sig)     | 2200 | 1.0      | yes      |
| 105014 | ZBHb (sig)     | 2400 | 0.4      | yes      |
| 105015 | ZBHb (sig)     | 2400 | 1.0      | yes      |
| 105016 | WBHb (sig)     | 1000 | 0.4      | yes      |
| 105017 | WBHb (sig)     | 1000 | 1.0      | yes      |
| 105018 | WBHb (sig)     | 1200 | 0.4      | yes      |
| 105019 | WBHb (sig)     | 1200 | 1.0      | yes      |
| 105020 | WBHb (sig)     | 1400 | 0.4      | yes      |
| 105021 | WBHb (sig)     | 1400 | 1.0      | yes      |
| 105022 | WBHb (sig)     | 1600 | 0.4      | yes      |
| 105023 | WBHb (sig)     | 1600 | 1.0      | yes      |
| 105024 | WBHb (sig)     | 1800 | 0.4      | yes      |
| 105025 | WBHb (sig)     | 1800 | 1.0      | yes      |
| 105026 | WBHb (sig)     | 2000 | 0.4      | yes      |
| 105027 | WBHb (sig)     | 2000 | 1.0      | yes      |
| 105028 | WBHb (sig)     | 2200 | 0.4      | yes      |
| 105029 | WBHb (sig)     | 2200 | 1.0      | yes      |
| 105030 | WBHb (sig)     | 2400 | 0.4      | yes      |
| 105031 | WBHb (sig)     | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |
