#### VLB Hb(yy) nominal samples, including t-channel processes (with reweighting)

| ------ | -------------- | ---- | -------- | -------- |
| DSID   | mode           | mass | coupling | reweight |
| ------ | -------------- | ---- | -------- | -------- |
| 104000 | ZBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 104001 | ZBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 104002 | ZBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 104003 | ZBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 104004 | ZBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 104005 | ZBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 104006 | ZBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 104007 | ZBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 104008 | ZBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 104009 | ZBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 104010 | ZBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 104011 | ZBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 104012 | ZBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 104013 | ZBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 104014 | ZBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 104015 | ZBH(yy)b (sig) | 2400 | 1.0      | yes      |
| 104016 | WBH(yy)b (sig) | 1000 | 0.4      | yes      |
| 104017 | WBH(yy)b (sig) | 1000 | 1.0      | yes      |
| 104018 | WBH(yy)b (sig) | 1200 | 0.4      | yes      |
| 104019 | WBH(yy)b (sig) | 1200 | 1.0      | yes      |
| 104020 | WBH(yy)b (sig) | 1400 | 0.4      | yes      |
| 104021 | WBH(yy)b (sig) | 1400 | 1.0      | yes      |
| 104022 | WBH(yy)b (sig) | 1600 | 0.4      | yes      |
| 104023 | WBH(yy)b (sig) | 1600 | 1.0      | yes      |
| 104024 | WBH(yy)b (sig) | 1800 | 0.4      | yes      |
| 104025 | WBH(yy)b (sig) | 1800 | 1.0      | yes      |
| 104026 | WBH(yy)b (sig) | 2000 | 0.4      | yes      |
| 104027 | WBH(yy)b (sig) | 2000 | 1.0      | yes      |
| 104028 | WBH(yy)b (sig) | 2200 | 0.4      | yes      |
| 104029 | WBH(yy)b (sig) | 2200 | 1.0      | yes      |
| 104030 | WBH(yy)b (sig) | 2400 | 0.4      | yes      |
| 104031 | WBH(yy)b (sig) | 2400 | 1.0      | yes      |
| ------ | -------------- | ---- | -------- | -------- |

